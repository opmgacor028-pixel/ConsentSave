package com.consent.save
// Placeholder for future shared-media handling extensions.
