package com.consent.save

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage

class MainActivity : ComponentActivity() {
    private var sharedUri by mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedUri = intent?.getParcelableExtra(Intent.EXTRA_STREAM)
        setContent { ConsentSaveApp(sharedUri) }
    }

    private fun saveImage(uri: Uri) {
        val resolver = contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "ConsentSave_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ConsentSave")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val target = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (target == null) {
            Toast.makeText(this, "Gagal membuat file", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            resolver.openInputStream(uri)?.use { input ->
                resolver.openOutputStream(target)?.use { output -> input.copyTo(output) }
            } ?: error("Media tidak dapat dibaca")
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(target, values, null, null)
            Toast.makeText(this, "Media tersimpan di Pictures/ConsentSave", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            resolver.delete(target, null, null)
            Toast.makeText(this, "Gagal menyimpan: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    @Composable
    fun ConsentSaveApp(uri: Uri?) {
        var showConsent by remember { mutableStateOf(uri != null) }
        MaterialTheme(colorScheme = darkColorScheme(
            background = Color(0xFF0B0F14),
            surface = Color(0xFF151B23),
            primary = Color(0xFF38F2B3),
            onPrimary = Color(0xFF07110D)
        )) {
            Surface(modifier = Modifier.fillMaxSize()) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(Modifier.height(24.dp))
                    Text("ConsentSave", style = MaterialTheme.typography.headlineMedium)
                    Text(
                        "Simpan media yang memang dibagikan untuk disimpan",
                        color = Color(0xFFA8B2BF),
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    Spacer(Modifier.height(28.dp))

                    if (uri == null) {
                        Icon(Icons.Default.Save, null, tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(72.dp))
                        Spacer(Modifier.height(16.dp))
                        Text("Bagikan foto ke ConsentSave dari aplikasi yang menyediakan media secara resmi.")
                    } else {
                        Card(shape = RoundedCornerShape(20.dp)) {
                            AsyncImage(
                                model = uri,
                                contentDescription = "Preview",
                                modifier = Modifier.fillMaxWidth().height(360.dp),
                                contentScale = ContentScale.Fit
                            )
                        }
                        Spacer(Modifier.height(20.dp))
                        Button(
                            onClick = { showConsent = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Save, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Simpan")
                        }
                    }
                }
            }
            if (showConsent && uri != null) {
                Dialog(onDismissRequest = { showConsent = false }) {
                    Card(shape = RoundedCornerShape(24.dp)) {
                        Column(Modifier.padding(24.dp)) {
                            Icon(Icons.Default.CheckCircle, null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(42.dp))
                            Spacer(Modifier.height(12.dp))
                            Text("Persetujuan penyimpanan",
                                style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.height(8.dp))
                            Text("Simpan hanya media yang tersedia melalui mekanisme berbagi resmi atau dengan izin pemilik.")
                            Spacer(Modifier.height(20.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                TextButton(onClick = { showConsent = false }) { Text("Batal") }
                                Button(onClick = {
                                    saveImage(uri)
                                    showConsent = false
                                }) { Text("Simpan") }
                            }
                        }
                    }
                }
            }
        }
    }
}
